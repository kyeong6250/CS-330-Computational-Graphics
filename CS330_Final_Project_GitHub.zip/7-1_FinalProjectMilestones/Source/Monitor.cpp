///////////////////////////////////////////////////////////////////////////////
// Monitor.cpp
// ===========
// renders the textured monitor as a reusable class instead of placing all
// of its draw calls inside SceneManager
//
//  AUTHOR: Kyeong Hun Yang - CS 330 Final Project
///////////////////////////////////////////////////////////////////////////////

#include "Monitor.h"

#include <glm/gtx/transform.hpp>

namespace
{
    // shader uniform names
    const char* g_ModelName = "model";
    const char* g_UseTextureName = "bUseTexture";
    const char* g_TextureValueName = "objectTexture";
    const char* g_UVScaleName = "UVscale";
    const char* g_UseOverlayName = "bUseOverlay";
    const char* g_OverlayTextureName = "overlayTexture";
    const char* g_UnlitName = "unlit";

    // Texel density: how many times a tiled texture repeats per world unit.
    // Every metal part uses this same value, so a stripe on the chin is the
    // same width as a stripe on the stand or foot. If each part used its own
    // hand-picked UV scale, the grain would jump in size at every seam.
    const float METAL_TILES_PER_UNIT = 0.5f;
    const float BEZEL_TILES_PER_UNIT = 0.5f;
}

/***********************************************************
 *  Monitor()
 *
 *  Stores the shared shader and mesh objects. The meshes are
 *  loaded once by SceneManager and reused by every part here.
 ***********************************************************/
Monitor::Monitor(ShaderManager* pShaderManager, ShapeMeshes* pBasicMeshes)
{
    m_pShaderManager = pShaderManager;
    m_pBasicMeshes = pBasicMeshes;
}

/***********************************************************
 *  SetTransformations()
 *
 *  Builds the model matrix. Scale is applied first, then the
 *  X, Y, Z rotations, then the translation.
 ***********************************************************/
void Monitor::SetTransformations(
    glm::vec3 scaleXYZ,
    float xRotationDegrees,
    float yRotationDegrees,
    float zRotationDegrees,
    glm::vec3 positionXYZ)
{
    glm::mat4 scale = glm::scale(scaleXYZ);
    glm::mat4 rotationX = glm::rotate(glm::radians(xRotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
    glm::mat4 rotationY = glm::rotate(glm::radians(yRotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
    glm::mat4 rotationZ = glm::rotate(glm::radians(zRotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
    glm::mat4 translation = glm::translate(positionXYZ);

    glm::mat4 model = translation * rotationX * rotationY * rotationZ * scale;
    m_pShaderManager->setMat4Value(g_ModelName, model);
}

/***********************************************************
 *  SetTexture()
 *
 *  Turns texturing on, selects the texture slot, and sets how
 *  many times the image repeats in U and V.
 ***********************************************************/
void Monitor::SetTexture(int textureSlot, float uScale, float vScale)
{
    m_pShaderManager->setIntValue(g_UseTextureName, true);
    m_pShaderManager->setSampler2DValue(g_TextureValueName, textureSlot);
    m_pShaderManager->setVec2Value(g_UVScaleName, glm::vec2(uScale, vScale));
}

/***********************************************************
 *  SetTiledTexture()
 *
 *  Tiling technique. The UV scale is calculated from the size
 *  of the shape's most visible face instead of being guessed,
 *  so the texture keeps the same density on every part.
 ***********************************************************/
void Monitor::SetTiledTexture(int textureSlot, float faceWidth, float faceHeight)
{
    SetTexture(textureSlot,
        faceWidth * METAL_TILES_PER_UNIT,
        faceHeight * METAL_TILES_PER_UNIT);
}

/***********************************************************
 *  SetOverlay() / ClearOverlay()
 *
 *  Overlapping technique. The overlay texture is blended on
 *  top of the base texture using the overlay's alpha channel.
 ***********************************************************/
void Monitor::SetOverlay(int textureSlot)
{
    m_pShaderManager->setBoolValue(g_UseOverlayName, true);
    m_pShaderManager->setSampler2DValue(g_OverlayTextureName, textureSlot);
}

void Monitor::ClearOverlay()
{
    m_pShaderManager->setBoolValue(g_UseOverlayName, false);
}

/***********************************************************
 *  Render()
 *
 *  Draws the whole monitor: the display on top of the stand.
 ***********************************************************/
void Monitor::Render(const MonitorTextures& textures)
{
    RenderDisplay(textures);
    RenderStand(textures);
}

/***********************************************************
 *  RenderDisplay()
 *
 *  Draws the housing, bezel, screen, and chin.
 ***********************************************************/
void Monitor::RenderDisplay(const MonitorTextures& textures)
{
    // Silver housing (6.40 x 4.15 x 0.30 box). The tiling is sized to the
    // large back face, which is the main housing surface the camera sees.
    SetTransformations(glm::vec3(6.40f, 4.15f, 0.30f),
        0.0f, 0.0f, 0.0f, glm::vec3(0.0f, 3.10f, 0.0f));
    SetTiledTexture(textures.metal, 6.40f, 4.15f);
    m_pBasicMeshes->DrawBoxMesh();

    // Black bezel in front of the housing. Uses its own subtle texture
    // so the border reads as a separate glass/plastic part.
    SetTransformations(glm::vec3(6.40f, 3.60f, 0.06f),
        0.0f, 0.0f, 0.0f, glm::vec3(0.0f, 3.375f, 0.17f));
    SetTexture(textures.bezel,
        6.40f * BEZEL_TILES_PER_UNIT,
        3.60f * BEZEL_TILES_PER_UNIT);
    m_pBasicMeshes->DrawBoxMesh();

    // Screen: a plane rotated to face the camera. The UI image was made at
    // the plane's 2.98:1.57 ratio, so a UV scale of 1 shows it once with no
    // stretching. A transparent glare image is layered on top to look like
    // light reflecting off the glass. The screen is unlit because a real
    // display gives off its own light.
    SetTransformations(glm::vec3(2.98f, 1.0f, 1.57f),
        90.0f, 0.0f, 0.0f, glm::vec3(0.0f, 3.375f, 0.205f));
    SetTexture(textures.screen);
    SetOverlay(textures.glare);
    m_pShaderManager->setBoolValue(g_UnlitName, true);
    m_pBasicMeshes->DrawPlaneMesh();
    m_pShaderManager->setBoolValue(g_UnlitName, false);
    ClearOverlay();

    // Silver chin below the screen. Same texel density as the housing, so
    // the brushed lines continue at the same width across the joint.
    SetTransformations(glm::vec3(6.40f, 0.55f, 0.04f),
        0.0f, 0.0f, 0.0f, glm::vec3(0.0f, 1.30f, 0.17f));
    SetTiledTexture(textures.metal, 6.40f, 0.55f);
    m_pBasicMeshes->DrawBoxMesh();
}

/***********************************************************
 *  RenderStand()
 *
 *  Draws the tapered support and the flat foot.
 ***********************************************************/
void Monitor::RenderStand(const MonitorTextures& textures)
{
    // Tapered support: a prism rotated -90 degrees about X so the wide edge
    // rests on the foot and the point meets the chin.
    SetTransformations(glm::vec3(1.40f, 0.36f, 1.10f),
        -90.0f, 0.0f, 0.0f, glm::vec3(0.0f, 0.72f, 0.0f));
    SetTiledTexture(textures.metal, 1.40f, 1.10f);
    m_pBasicMeshes->DrawPrismMesh();

    // Flat foot. The tiling is sized to the top face (1.95 x 1.20), which
    // is the most visible face from the camera's height.
    SetTransformations(glm::vec3(1.95f, 0.18f, 1.20f),
        0.0f, 0.0f, 0.0f, glm::vec3(0.0f, 0.09f, 0.25f));
    SetTiledTexture(textures.metal, 1.95f, 1.20f);
    m_pBasicMeshes->DrawBoxMesh();
}
