///////////////////////////////////////////////////////////////////////////////
// ViewManager.cpp
// ===============
// manages camera movement, mouse interaction, and scene projection
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//  Student updates: final-project camera navigation, adjustable speed, and projection controls
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

namespace
{
    const int WINDOW_WIDTH = 1000;
    const int WINDOW_HEIGHT = 800;
    const char* g_ViewName = "view";
    const char* g_ProjectionName = "projection";

    Camera* g_pCamera = nullptr;

    // Mouse state used to calculate cursor movement between frames.
    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;

    // Frame timing keeps keyboard movement consistent on different computers.
    float gDeltaTime = 0.0f;
    float gLastFrame = 0.0f;

    bool gOrthographicProjection = false;
    bool gPKeyWasPressed = false;
    bool gOKeyWasPressed = false;
}

ViewManager::ViewManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_pWindow = NULL;

    // Start above and in front of the desk, tilted down 11 degrees, with a
    // 43-degree field of view so every object is in frame at launch.
    // Yaw and pitch initialize all camera direction vectors consistently.
    g_pCamera = new Camera(
        glm::vec3(0.0f, 4.6f, 15.2f),
        glm::vec3(0.0f, 1.0f, 0.0f),
        -90.0f,
        -11.0f);
    g_pCamera->Zoom = 43.0f;
    g_pCamera->MovementSpeed = 4.0f;

    // The starter Camera turns only 0.01 degrees per pixel of mouse movement,
    // which makes mouse-look too slow to be useful. 0.1 degrees per pixel
    // gives smooth, controllable pitch and yaw.
    g_pCamera->MouseSensitivity = 0.1f;
}

ViewManager::~ViewManager()
{
    m_pShaderManager = NULL;
    m_pWindow = NULL;

    if (NULL != g_pCamera)
    {
        delete g_pCamera;
        g_pCamera = NULL;
    }
}

GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
    GLFWwindow* window = glfwCreateWindow(
        WINDOW_WIDTH,
        WINDOW_HEIGHT,
        windowTitle,
        NULL, NULL);

    if (window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return NULL;
    }

    glfwMakeContextCurrent(window);

    // Capture the cursor so camera rotation is not limited by window edges.
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
    glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);
    glfwSetScrollCallback(window, &ViewManager::Mouse_Scroll_Callback);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    m_pWindow = window;
    return window;
}

void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos)
{
    // Mouse-look remains active in both projection modes so switching between
    // perspective and orthographic does not change the camera orientation.
    if (g_pCamera == nullptr)
    {
        return;
    }

    if (gFirstMouse)
    {
        gLastX = static_cast<float>(xMousePos);
        gLastY = static_cast<float>(yMousePos);
        gFirstMouse = false;
    }

    float xOffset = static_cast<float>(xMousePos) - gLastX;
    float yOffset = gLastY - static_cast<float>(yMousePos);

    gLastX = static_cast<float>(xMousePos);
    gLastY = static_cast<float>(yMousePos);

    g_pCamera->ProcessMouseMovement(xOffset, yOffset);
}

void ViewManager::Mouse_Scroll_Callback(GLFWwindow* window, double xOffset, double yOffset)
{
    if (g_pCamera != nullptr)
    {
        // The course Camera class uses scroll input to adjust travel speed.
        g_pCamera->ProcessMouseScroll(static_cast<float>(yOffset));
    }
}

void ViewManager::ProcessKeyboardEvents()
{
    if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
    {
        glfwSetWindowShouldClose(m_pWindow, true);
    }

    // WASD controls horizontal/depth movement; Q/E controls vertical movement.
    if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(RIGHT, gDeltaTime);
    if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(DOWN, gDeltaTime);
    if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(UP, gDeltaTime);

    // Change projection only once per key press instead of every frame held.
    const bool pPressed = glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS;
    const bool oPressed = glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_PRESS;

    if (pPressed && !gPKeyWasPressed)
    {
        gOrthographicProjection = false;
        gFirstMouse = true;
    }
    if (oPressed && !gOKeyWasPressed)
    {
        gOrthographicProjection = true;
        gFirstMouse = true;
    }

    gPKeyWasPressed = pPressed;
    gOKeyWasPressed = oPressed;
}

void ViewManager::PrepareSceneView()
{
    glm::mat4 view;
    glm::mat4 projection;

    float currentFrame = static_cast<float>(glfwGetTime());
    gDeltaTime = currentFrame - gLastFrame;
    gLastFrame = currentFrame;

    ProcessKeyboardEvents();

    const float aspectRatio = static_cast<float>(WINDOW_WIDTH) / static_cast<float>(WINDOW_HEIGHT);

    // Both projections use the same camera position and orientation. Only the
    // projection matrix changes when O or P is pressed.
    view = g_pCamera->GetViewMatrix();

    if (gOrthographicProjection)
    {
        const float halfHeight = 5.5f;
        const float halfWidth = halfHeight * aspectRatio;
        projection = glm::ortho(-halfWidth, halfWidth, -halfHeight, halfHeight, 0.1f, 100.0f);
    }
    else
    {
        projection = glm::perspective(
            glm::radians(g_pCamera->Zoom),
            aspectRatio,
            0.1f,
            100.0f);
    }

    if (m_pShaderManager != NULL)
        m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);

    if (m_pShaderManager != NULL)
    {
        m_pShaderManager->setMat4Value(g_ViewName, view);
        m_pShaderManager->setMat4Value(g_ProjectionName, projection);
    }
}
