///////////////////////////////////////////////////////////////////////////////
// SceneManager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
//
//  MODIFIED BY: Kyeong Hun Yang - CS 330 Final Project
//  Built a low-polygon desktop workspace from reusable primitive meshes,
//  added high-resolution textures, Phong materials, and three scene lights.
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
	m_monitor = new Monitor(m_pShaderManager, m_basicMeshes);
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	DestroyGLTextures();
	m_pShaderManager = NULL;
	delete m_monitor;
	m_monitor = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		// Use the mipmaps when a texture is shrunk on screen. A tiled texture
		// far from the camera (such as the back of the desk) would otherwise
		// shimmer and show wavy moire patterns.
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			stbi_image_free(image);
			glBindTexture(GL_TEXTURE_2D, 0);
			glDeleteTextures(1, &textureID);
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		if (m_loadedTextures >= 16)
		{
			std::cout << "Texture limit reached; cannot register " << tag << std::endl;
			glDeleteTextures(1, &textureID);
			return false;
		}
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(bFound);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}


/***********************************************************
 *  DefineObjectMaterials()
 *
 *  Defines Phong material properties for the different real-
 *  world surfaces used throughout the workspace.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	m_objectMaterials.clear();

	OBJECT_MATERIAL wallMaterial;
	wallMaterial.ambientColor = glm::vec3(0.96f, 0.96f, 0.95f);
	wallMaterial.ambientStrength = 0.42f;
	wallMaterial.diffuseColor = glm::vec3(0.92f, 0.92f, 0.90f);
	wallMaterial.specularColor = glm::vec3(0.05f, 0.05f, 0.05f);
	wallMaterial.shininess = 2.0f;
	wallMaterial.tag = "wall";
	m_objectMaterials.push_back(wallMaterial);

	OBJECT_MATERIAL deskMaterial;
	deskMaterial.ambientColor = glm::vec3(1.0f, 0.98f, 0.94f);
	deskMaterial.ambientStrength = 0.32f;
	deskMaterial.diffuseColor = glm::vec3(0.90f, 0.88f, 0.84f);
	deskMaterial.specularColor = glm::vec3(0.35f, 0.33f, 0.30f);
	deskMaterial.shininess = 18.0f;
	deskMaterial.tag = "desk";
	m_objectMaterials.push_back(deskMaterial);

	OBJECT_MATERIAL monitorMaterial;
	monitorMaterial.ambientColor = glm::vec3(0.90f, 0.92f, 0.95f);
	monitorMaterial.ambientStrength = 0.28f;
	monitorMaterial.diffuseColor = glm::vec3(0.88f, 0.90f, 0.94f);
	monitorMaterial.specularColor = glm::vec3(0.72f, 0.74f, 0.80f);
	monitorMaterial.shininess = 48.0f;
	monitorMaterial.tag = "monitor";
	m_objectMaterials.push_back(monitorMaterial);

	OBJECT_MATERIAL plasticMaterial;
	plasticMaterial.ambientColor = glm::vec3(0.92f, 0.92f, 0.90f);
	plasticMaterial.ambientStrength = 0.28f;
	plasticMaterial.diffuseColor = glm::vec3(0.86f, 0.86f, 0.84f);
	plasticMaterial.specularColor = glm::vec3(0.28f, 0.28f, 0.28f);
	plasticMaterial.shininess = 20.0f;
	plasticMaterial.tag = "plastic";
	m_objectMaterials.push_back(plasticMaterial);

	OBJECT_MATERIAL ceramicMaterial;
	ceramicMaterial.ambientColor = glm::vec3(0.88f, 0.88f, 0.88f);
	ceramicMaterial.ambientStrength = 0.24f;
	ceramicMaterial.diffuseColor = glm::vec3(0.76f, 0.76f, 0.76f);
	ceramicMaterial.specularColor = glm::vec3(0.60f, 0.60f, 0.60f);
	ceramicMaterial.shininess = 38.0f;
	ceramicMaterial.tag = "ceramic";
	m_objectMaterials.push_back(ceramicMaterial);

	OBJECT_MATERIAL paperMaterial;
	paperMaterial.ambientColor = glm::vec3(0.92f, 0.90f, 0.86f);
	paperMaterial.ambientStrength = 0.34f;
	paperMaterial.diffuseColor = glm::vec3(0.88f, 0.86f, 0.80f);
	paperMaterial.specularColor = glm::vec3(0.10f, 0.10f, 0.10f);
	paperMaterial.shininess = 4.0f;
	paperMaterial.tag = "paper";
	m_objectMaterials.push_back(paperMaterial);

	OBJECT_MATERIAL pencilMaterial;
	pencilMaterial.ambientColor = glm::vec3(0.85f, 0.70f, 0.50f);
	pencilMaterial.ambientStrength = 0.30f;
	pencilMaterial.diffuseColor = glm::vec3(0.80f, 0.65f, 0.45f);
	pencilMaterial.specularColor = glm::vec3(0.16f, 0.16f, 0.16f);
	pencilMaterial.shininess = 8.0f;
	pencilMaterial.tag = "pencil";
	m_objectMaterials.push_back(pencilMaterial);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  Three point lights create a soft studio-like workspace:
 *  a warm key light, a subtle blue fill, and a neutral back
 *  light. The colored fill satisfies the project requirement
 *  while the other lights prevent complete shadow as the
 *  camera moves around the scene.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// Key light - a warm white point light above and in front of the desk,
	// to the viewer's right. It provides most of the diffuse light and the
	// specular highlights.
	m_pShaderManager->setVec3Value("lightSources[0].position", 5.5f, 8.5f, 7.0f);
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.20f, 0.19f, 0.17f);
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 0.88f, 0.82f, 0.72f);
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 1.00f, 0.96f, 0.90f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.68f);

	// Colored fill light - a cool blue that separates the silver monitor
	// from the neutral background without overpowering the warm key light.
	m_pShaderManager->setVec3Value("lightSources[1].position", -6.0f, 5.5f, 4.0f);
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.08f, 0.10f, 0.16f);
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.22f, 0.32f, 0.58f);
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", 0.20f, 0.30f, 0.62f);
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.32f);

	// Back light - a neutral point light behind the monitor. It lights the
	// back of the monitor and the far sides of the objects so nothing turns
	// completely dark when the camera moves around the scene.
	m_pShaderManager->setVec3Value("lightSources[2].position", 0.0f, 4.0f, -7.5f);
	m_pShaderManager->setVec3Value("lightSources[2].ambientColor", 0.05f, 0.05f, 0.05f);
	m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", 0.42f, 0.42f, 0.44f);
	m_pShaderManager->setVec3Value("lightSources[2].specularColor", 0.80f, 0.80f, 0.82f);
	m_pShaderManager->setFloatValue("lightSources[2].specularIntensity", 0.45f);

	m_pShaderManager->setBoolValue("bUseLighting", true);
}

/***********************************************************
 *  PrepareScene()
 *
 *  Loads all high-resolution texture assets and the primitive
 *  meshes that are reused to construct the workspace.
 ***********************************************************/
void SceneManager::PrepareScene()
{
	CreateGLTexture("textures/desk_wood.png", "deskWood");
	CreateGLTexture("textures/brushed_metal.png", "monitorMetal");
	CreateGLTexture("textures/dark_bezel.png", "monitorBezel");
	CreateGLTexture("textures/screen_display.png", "monitorScreen");
	CreateGLTexture("textures/screen_glare.png", "monitorGlare");
	CreateGLTexture("textures/keyboard_keys.png", "keyboard");
	CreateGLTexture("textures/mouse_plastic.png", "mouse");
	CreateGLTexture("textures/mug_ceramic.png", "mug");
	CreateGLTexture("textures/book_cover.png", "book");
	CreateGLTexture("textures/cup_ceramic.png", "pencilCup");
	BindGLTextures();

	DefineObjectMaterials();
	SetupSceneLights();

	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadPrismMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadTorusMesh(0.22f);
}

/***********************************************************
 *  RenderScene()
 *
 *  Recreates the selected desktop photograph using a low-
 *  polygon monitor, keyboard, mouse, mug, books, pencil cup,
 *  and a textured desktop surface.
 ***********************************************************/
void SceneManager::RenderScene()
{
	// The light backdrop reproduces the bright wall in the reference photo and
	// prevents the monitor silhouette from disappearing into the clear color.
	RenderBackdrop();

	SetShaderMaterial("desk");
	RenderDesk();

	SetShaderMaterial("monitor");
	MonitorTextures monitorTextures;
	monitorTextures.metal = FindTextureSlot("monitorMetal");
	monitorTextures.bezel = FindTextureSlot("monitorBezel");
	monitorTextures.screen = FindTextureSlot("monitorScreen");
	monitorTextures.glare = FindTextureSlot("monitorGlare");
	m_monitor->Render(monitorTextures);

	RenderKeyboard();
	RenderMouse();
	RenderMug();
	RenderBookStack();
	RenderPencilHolder();
}

/***********************************************************
 *  RenderBackdrop()
 *
 *  A simple vertical plane represents the light wall behind
 *  the desk. It is intentionally untextured so the workspace
 *  remains the visual focus, matching the reference image.
 ***********************************************************/
void SceneManager::RenderBackdrop()
{
	// The plane mesh spans -1 to +1, so an X scale of 12 makes the wall as
	// wide as the desk and keeps its edges out of the default camera view.
	SetShaderMaterial("wall");
	SetTransformations(glm::vec3(12.0f, 1.0f, 5.6f),
		90.0f, 0.0f, 0.0f, glm::vec3(0.0f, 5.1f, -2.7f));
	SetShaderColor(0.94f, 0.94f, 0.92f, 1.0f);
	m_basicMeshes->DrawPlaneMesh();
}

/***********************************************************
 *  RenderDesk()
 *
 *  Draws the desktop as one large plane at y = 0. Every other
 *  object is placed so its base rests on this surface.
 ***********************************************************/
void SceneManager::RenderDesk()
{
	// The plane mesh spans -1 to +1, so this scale makes a 24 x 16 desk.
	SetTransformations(glm::vec3(12.0f, 1.0f, 8.0f),
		0.0f, 0.0f, 0.0f, glm::vec3(0.0f));

	// Tile the wood texture 6 x 4 times so the 24 x 16 desk keeps the
	// texture's square proportions instead of stretching one copy.
	SetShaderTexture("deskWood");
	SetTextureUVScale(6.0f, 4.0f);
	m_basicMeshes->DrawPlaneMesh();
}

/***********************************************************
 *  RenderKeyboard()
 *
 *  A single flattened box keeps the keyboard low polygon;
 *  the key pattern is supplied by the texture.
 ***********************************************************/
void SceneManager::RenderKeyboard()
{
	// The box mesh is centered on its position, so a y of 0.065 (half of
	// the 0.13 height) rests the keyboard on the desk.
	SetShaderMaterial("plastic");
	SetTransformations(glm::vec3(4.55f, 0.13f, 1.10f),
		0.0f, 0.0f, 0.0f, glm::vec3(0.05f, 0.065f, 3.05f));
	SetShaderTexture("keyboard");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();
}

/***********************************************************
 *  RenderMouse()
 *
 *  The mouse is the top half of a sphere, flattened and
 *  stretched front to back into a low dome.
 ***********************************************************/
void SceneManager::RenderMouse()
{
	// The half sphere's flat side is at its origin, so y = 0 rests it on
	// the desk. The -8 degree Y rotation angles it slightly toward the
	// keyboard, the way a mouse usually sits beside one.
	SetShaderMaterial("plastic");
	SetTransformations(glm::vec3(0.56f, 0.36f, 0.82f),
		0.0f, -8.0f, 0.0f, glm::vec3(3.75f, 0.0f, 3.00f));
	SetShaderTexture("mouse");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawHalfSphereMesh();
}

/***********************************************************
 *  RenderMug()
 *
 *  The mug is a complex object built from an open-top
 *  cylinder and a half torus handle.
 ***********************************************************/
void SceneManager::RenderMug()
{
	// The cylinder mesh runs from y = 0 to y = 1, so its position is the
	// bottom of the mug. The small 0.005 lift keeps the mug's floor from
	// flickering against the desk, which sits at exactly y = 0. The top cap
	// is skipped so the mug is open.
	SetShaderMaterial("ceramic");
	SetTransformations(glm::vec3(0.50f, 0.95f, 0.50f),
		0.0f, 0.0f, 0.0f, glm::vec3(-3.55f, 0.005f, 2.05f));
	SetShaderTexture("mug");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh(false, true, true);

	// Half torus handle. Rotating -90 degrees about Z turns the arc to face
	// right, and the scale sizes it to about 0.55 tall. Its ends sit on the
	// mug's outer wall at x = -3.05, so the handle is attached without the
	// open tube ends poking through to the inside of the mug.
	SetTransformations(glm::vec3(0.225f, 0.25f, 0.25f),
		0.0f, 0.0f, -90.0f, glm::vec3(-3.05f, 0.48f, 2.05f));
	SetShaderTexture("mug");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawHalfTorusMesh();
}

/***********************************************************
 *  RenderBook()
 *
 *  Draws one book as a single textured box. The book texture
 *  shows the dark covers and light page edges on the sides,
 *  so one box reads as a book without extra geometry.
 ***********************************************************/
void SceneManager::RenderBook(glm::vec3 positionXYZ, glm::vec3 scaleXYZ, float yRotationDegrees)
{
	SetShaderMaterial("paper");
	SetTransformations(scaleXYZ, 0.0f, yRotationDegrees, 0.0f, positionXYZ);
	SetShaderTexture("book");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();
}

/***********************************************************
 *  RenderBookStack()
 *
 *  Stacks four books on the left side of the desk, each a
 *  little smaller and turned slightly differently.
 ***********************************************************/
void SceneManager::RenderBookStack()
{
	// Each box is centered on its position, so each y value is the top of
	// the book below plus half of this book's thickness. The books rest on
	// one another with no gaps.
	RenderBook(glm::vec3(-5.25f, 0.100f, 2.70f), glm::vec3(2.25f, 0.20f, 1.42f), -5.0f);
	RenderBook(glm::vec3(-5.18f, 0.290f, 2.64f), glm::vec3(2.00f, 0.18f, 1.30f), 4.0f);
	RenderBook(glm::vec3(-5.10f, 0.465f, 2.58f), glm::vec3(1.78f, 0.17f, 1.18f), -2.0f);
	RenderBook(glm::vec3(-5.02f, 0.625f, 2.52f), glm::vec3(1.55f, 0.15f, 1.04f), 3.0f);
}

/***********************************************************
 *  RenderPencil()
 *
 *  A cylinder body and a cone tip form one reusable pencil.
 *  Small tilts keep the cup from looking too mechanically
 *  uniform.
 ***********************************************************/
void SceneManager::RenderPencil(glm::vec3 positionXYZ, float height, glm::vec4 color, float zTiltDegrees)
{
	// Body. The caps are skipped because the bottom sits inside the cup and
	// the top is covered by the tip; this keeps each pencil at 250 triangles.
	SetShaderMaterial("pencil");
	SetShaderColor(color.r, color.g, color.b, color.a);
	SetTransformations(glm::vec3(0.065f, height, 0.065f),
		0.0f, 0.0f, zTiltDegrees, positionXYZ);
	m_basicMeshes->DrawCylinderMesh(false, false, true);

	// The body leans by zTiltDegrees, so its top point moves sideways as
	// well as up. Rotating (0, height, 0) by the same tilt finds that point,
	// which keeps the tip attached to the body.
	const float tiltRadians = glm::radians(zTiltDegrees);
	const glm::vec3 tipBase = positionXYZ +
		glm::vec3(-sin(tiltRadians) * height, cos(tiltRadians) * height, 0.0f);

	// Sharpened wood tip: same radius and tilt as the body. Its base is
	// hidden against the body, so the bottom cap is skipped.
	SetShaderColor(0.74f, 0.55f, 0.34f, 1.0f);
	SetTransformations(glm::vec3(0.065f, 0.18f, 0.065f),
		0.0f, 0.0f, zTiltDegrees, tipBase);
	m_basicMeshes->DrawConeMesh(false);
}

/***********************************************************
 *  RenderPencilHolder()
 *
 *  Draws the open pencil cup and the three pencils inside it.
 *  The whole object stays under 1,000 triangles (178 for the
 *  cup plus 250 for each pencil = 928).
 ***********************************************************/
void SceneManager::RenderPencilHolder()
{
	// The cylinder's base is at its origin, so y = 0.005 rests the cup on
	// the desk (the small lift prevents flicker against the desk surface).
	SetShaderMaterial("ceramic");
	SetTransformations(glm::vec3(0.58f, 0.92f, 0.58f),
		0.0f, 0.0f, 0.0f, glm::vec3(5.05f, 0.005f, 1.72f));
	SetShaderTexture("pencilCup");
	SetTextureUVScale(1.0f, 1.0f);
	// Leave the top cap off so the cylinder reads as a cup instead of a can.
	m_basicMeshes->DrawCylinderMesh(false, true, true);

	// Pencil bases start inside the cup, above its floor.
	RenderPencil(glm::vec3(4.80f, 0.26f, 1.68f), 1.18f, glm::vec4(0.22f, 0.22f, 0.24f, 1.0f), -8.0f);
	RenderPencil(glm::vec3(5.02f, 0.26f, 1.80f), 1.42f, glm::vec4(0.76f, 0.64f, 0.36f, 1.0f), 5.0f);
	RenderPencil(glm::vec3(5.23f, 0.28f, 1.66f), 1.08f, glm::vec4(0.38f, 0.42f, 0.45f, 1.0f), 10.0f);
}
