///////////////////////////////////////////////////////////////////////////////
// Monitor.h
// =========
// encapsulates the textured monitor (the complex object) in the CS 330
// final project scene
//
//  AUTHOR: Kyeong Hun Yang - CS 330 Milestones Four and Five
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "ShapeMeshes.h"

#include <glm/glm.hpp>

/***********************************************************
 *  MonitorTextures
 *
 *  Texture slot indices for each material used by the
 *  monitor. Grouping them keeps Render() to one argument.
 ***********************************************************/
struct MonitorTextures
{
    int metal;      // brushed aluminum for housing, chin, and stand
    int bezel;      // dark border around the display
    int screen;     // on-screen user interface image
    int glare;      // transparent reflection layered over the screen
};

/***********************************************************
 *  Monitor
 *
 *  Draws the monitor from basic shapes. Each shape gets its
 *  own texture, and the brushed metal is tiled at one shared
 *  density so the grain lines up where the parts meet.
 ***********************************************************/
class Monitor
{
public:
    Monitor(ShaderManager* pShaderManager, ShapeMeshes* pBasicMeshes);

    // draw the complete monitor as one logical scene object
    void Render(const MonitorTextures& textures);

private:
    ShaderManager* m_pShaderManager;
    ShapeMeshes* m_pBasicMeshes;

    // draw the upper half: housing, bezel, screen, and chin
    void RenderDisplay(const MonitorTextures& textures);
    // draw the lower half: tapered support and foot
    void RenderStand(const MonitorTextures& textures);

    // build the model matrix (scale -> rotate -> translate)
    void SetTransformations(
        glm::vec3 scaleXYZ,
        float xRotationDegrees,
        float yRotationDegrees,
        float zRotationDegrees,
        glm::vec3 positionXYZ);

    // select a texture and how many times it repeats across a shape
    void SetTexture(int textureSlot, float uScale = 1.0f, float vScale = 1.0f);
    // tile a texture so it repeats a fixed number of times per world unit
    void SetTiledTexture(int textureSlot, float faceWidth, float faceHeight);
    // layer a second, transparent texture over the base texture
    void SetOverlay(int textureSlot);
    void ClearOverlay();
};
