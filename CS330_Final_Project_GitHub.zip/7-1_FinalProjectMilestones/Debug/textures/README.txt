CS 330 Final Project Texture Assets

All texture images in this folder were created specifically for this project as original procedural assets. They do not contain third-party copyrighted imagery. The tiled material textures are 1024 x 1024 pixels or larger and were designed to repeat without obvious seams, following the CS 330 Sourcing Textures Tutorial guidance.
