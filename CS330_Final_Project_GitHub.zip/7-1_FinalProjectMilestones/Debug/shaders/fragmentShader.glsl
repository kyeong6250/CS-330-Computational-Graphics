#version 330 core

in vec3 worldPosition;
in vec3 worldNormal;
in vec2 fragmentTextureCoordinate;

struct Material
{
    vec3 ambientColor;
    float ambientStrength;
    vec3 diffuseColor;
    vec3 specularColor;
    float shininess;
};

// One point light. The highlight size comes from the material's
// shininess exponent, so the light only sets color and intensity.
struct LightSource
{
    vec3 position;
    vec3 ambientColor;
    vec3 diffuseColor;
    vec3 specularColor;
    float specularIntensity;
};

uniform vec4 objectColor = vec4(1.0);
uniform sampler2D objectTexture;
uniform bool bUseTexture = false;
uniform bool unlit = false;
uniform bool bUseLighting = true;
uniform vec3 viewPosition;
uniform Material material;
// key, fill, and back light (set in SceneManager::SetupSceneLights)
#define TOTAL_LIGHTS 3
uniform LightSource lightSources[TOTAL_LIGHTS];

// Number of times the base texture repeats in U and V.
uniform vec2 UVscale = vec2(1.0, 1.0);

// Optional transparent texture blended over the base texture.
uniform sampler2D overlayTexture;
uniform bool bUseOverlay = false;

out vec4 outFragmentColor;

void main()
{
    vec4 baseColor = bUseTexture
        ? texture(objectTexture, fragmentTextureCoordinate * UVscale)
        : objectColor;

    if (bUseOverlay)
    {
        vec4 overlayColor = texture(overlayTexture, fragmentTextureCoordinate);
        baseColor.rgb = mix(baseColor.rgb, overlayColor.rgb, overlayColor.a);
    }

    // The monitor screen is emissive, so it can bypass scene lighting.
    if (unlit || !bUseLighting)
    {
        outFragmentColor = baseColor;
        return;
    }

    vec3 normal = normalize(worldNormal);
    vec3 viewDirection = normalize(viewPosition - worldPosition);
    vec3 ambientDiffuseTotal = vec3(0.0);
    vec3 specularTotal = vec3(0.0);

    // Phong lighting: ambient + diffuse + specular summed over every light.
    for (int i = 0; i < TOTAL_LIGHTS; ++i)
    {
        vec3 lightDirection = normalize(lightSources[i].position - worldPosition);

        vec3 ambient = lightSources[i].ambientColor *
                       material.ambientColor * material.ambientStrength;

        float diffuseAmount = max(dot(normal, lightDirection), 0.0);
        vec3 diffuse = diffuseAmount * lightSources[i].diffuseColor *
                       material.diffuseColor;

        vec3 reflectedDirection = reflect(-lightDirection, normal);
        float specularAmount = pow(
            max(dot(viewDirection, reflectedDirection), 0.0),
            max(material.shininess, 1.0));
        vec3 specular = specularAmount * lightSources[i].specularColor *
                        material.specularColor * lightSources[i].specularIntensity;

        ambientDiffuseTotal += ambient + diffuse;
        specularTotal += specular;
    }

    // Ambient and diffuse shade the texture, while the specular term is added
    // separately so a highlight can reflect from the textured desk surface.
    vec3 finalColor = baseColor.rgb * ambientDiffuseTotal + specularTotal;
    outFragmentColor = vec4(finalColor, baseColor.a);
}
