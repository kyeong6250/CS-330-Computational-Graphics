#version 330 core
layout (location = 0) in vec3 inVertexPosition;
layout (location = 1) in vec3 inVertexNormal;
layout (location = 2) in vec2 inTextureCoordinate;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

out vec3 worldPosition;
out vec3 worldNormal;
out vec2 fragmentTextureCoordinate;

void main()
{
    vec4 worldPos = model * vec4(inVertexPosition, 1.0);
    worldPosition = worldPos.xyz;
    worldNormal = mat3(transpose(inverse(model))) * inVertexNormal;
    fragmentTextureCoordinate = inTextureCoordinate;

    gl_Position = projection * view * worldPos;
}
